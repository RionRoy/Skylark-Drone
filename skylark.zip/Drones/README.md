# Executive BI Agent

This is a Streamlit application that implements a Business Intelligence Agent for Monday.com, powered by OpenAI's GPT models. It dynamically fetches data from Monday.com's Sales Pipeline and Operations tracking boards and provides executive-level insights.

## Prerequisites

1. Python 3.8+
2. A Monday.com account and API token.
3. An OpenAI API Key.

## Setup Instructions

1. **Install Dependencies**
   Open your terminal in this directory and run:
   ```bash
   pip install -r requirements.txt
   ```

2. **Environment Variables Configuration**
   Copy the provided `.env.example` file to `.env`:
   ```bash
   cp .env.example .env
   ```
   Open the `.env` file and fill in your actual API keys and Monday.com Board IDs:
   - `MONDAY_API_KEY`: Your Monday.com API v2 token (You can generate one in Developer section of Monday.com).
   - `OPENAI_API_KEY`: Your OpenAI API key.
   - `DEALS_BOARD_ID`: The board ID for your "Sales Pipeline / Deals Board".
   - `WORK_ORDERS_BOARD_ID`: The board ID for your "Operations / Work Order Tracker".

   *(Alternatively, you can input these directly into the app's sidebar when it's running.)*

3. **Run the Application**
   Start the Streamlit server by running:
   ```bash
   streamlit run app.py
   ```

4. **Usage**
   - The app will open in your default browser at `http://localhost:8501`.
   - You can enter inquiries like "How's the pipeline?" or "Give me a Leadership Update".
   - The agent will fetch live data from Monday.com boards and provide executive-level BI responses, adhering to the strict resilience and cleaning rules specified in the master prompt.
